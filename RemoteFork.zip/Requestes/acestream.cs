﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Common.Logging;
using RemoteFork.Network;
using Unosquare.Net;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using RemoteFork.Properties;
using Newtonsoft.Json;
using RemoteFork.Plugins;
using RemoteFork.Server;

namespace RemoteFork.Requestes
{
    internal class AceStream : BaseRequestHandler
    {
        internal static readonly string UrlPath = "/acestream";

        public override void Handle(HttpListenerRequest request, HttpListenerResponse response)
        {
            try
            {
                var result = string.Empty;
                var url = System.Web.HttpUtility.UrlDecode(request.RawUrl)?.Substring(UrlPath.Length);
                if (request.HttpMethod == "POST")
                {
                    StreamReader getPostParam = new StreamReader(request.InputStream, true);
                    var postData = getPostParam.ReadToEnd();
                    Console.WriteLine("POST ace"+ postData);
                    url = postData.Substring(2);
                }
                string s = "";
                if (url.Substring(0, 1) == "B"||url.Substring(0, 1) == "M")
                {
                    Console.WriteLine("M");
                    if (url.IndexOf("?box_mac") > 0) url = url.Substring(0, url.IndexOf("?box_mac"));
                    if (url.IndexOf("&box_mac") > 0) url = url.Substring(0, url.IndexOf("&box_mac"));
                    s = url.Substring(1);
                }
                else if (url.Substring(0, 1) == "U")
                {
                    url = url.Substring(1);
                    if (url.IndexOf("?box_mac") > 0) url = url.Substring(0, url.IndexOf("?box_mac"));
                    if (url.IndexOf("&box_mac") > 0) url = url.Substring(0, url.IndexOf("&box_mac"));
                    Dictionary<string, string> header = new Dictionary<string, string>();
                    if (url.IndexOf("OPT:") > 0)
                    {
                        var Headers = url.Substring(url.IndexOf("OPT:") + 4).Replace("--", "|").Split('|');
                        for (var i = 0; i < Headers.Length; i++)
                        {
                            if (Headers[i] == "ContentType")
                            {
                                if (!string.IsNullOrEmpty(request.Headers.Get("Range")))
                                {
                                    header["Range"] = request.Headers.Get("Range");
                                }
                                response.Headers.Add("Accept-Ranges", "bytes");
                                Console.WriteLine("reproxy with ContentType");
                                response.ContentType = Headers[++i];
                                continue;
                            }
                            header[Headers[i]] = Headers[++i];
                            Console.WriteLine(Headers[i - 1] + "=" + Headers[i]);
                        }
                        url = url.Substring(0, url.IndexOf("OPT:"));
                    }
                    else header = null;

                    Console.WriteLine("Get torrent by url:" + url);

                    var handler = new System.Net.Http.HttpClientHandler() { AllowAutoRedirect = true };
                    var httpClient = new System.Net.Http.HttpClient(handler);
                    HttpUtility.AddHeader(httpClient, header);
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                    System.Net.ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => { return true; };
                    
                    s = Convert.ToBase64String(httpClient.GetAsync(url).Result.Content.ReadAsByteArrayAsync().Result);
                   // Console.WriteLine("sb64="+s);

                }               
                response.Headers.AddWithoutValidate("Connection", "Close");
                Console.WriteLine("b64=" + s.Length);
                GetFileList(s,response);
                // response.AddHeader("Accept-Ranges", "bytes");


            }
            catch (Exception e)
            {
                Console.WriteLine("ParseAce=" + e.ToString());
                WriteResponse(response, e.ToString());
            }           
        }

        private string PortAce = "6878";
        public struct TorrentPlayList
        {
            public string IDX;
            public string Name;
            public string Link;
            public string Description;
            public string ImageLink;
        }
       
        public class AceFile
        {
            public string error { get; set; }
            public Dictionary<string, string> result { get; set; }
        }
        public class AceId
        {
            public string error { get; set; }
            public string content_id { get; set; }
        }
        public string GetID(string FileTorrentString64, HttpListenerResponse resp)
        {
            var handler = new System.Net.Http.HttpClientHandler() { AllowAutoRedirect = true };
            var httpClient = new System.Net.Http.HttpClient(handler);
            HttpUtility.AddHeader(httpClient, null);
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
            System.Net.ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => { return true; };
            System.Net.Http.StringContent queryString = new System.Net.Http.StringContent(FileTorrentString64, Encoding.UTF8, "application/octet-stream");
            var responseFromServer = httpClient.PostAsync("http://api.torrentstream.net/upload/raw", queryString).Result.Content.ReadAsStringAsync().Result;

            /*
            var FileTorrent = System.Text.Encoding.Default.GetBytes(FileTorrentString64);
            FileTorrent = System.Text.Encoding.Unicode.GetBytes(FileTorrentString64);
                        
            Console.WriteLine(FileTorrent);
            System.Net.WebRequest request = System.Net.WebRequest.Create("http://api.torrentstream.net/upload/raw");
            request.Method = "POST";
            request.ContentType = "application/octet-stream";
            request.ContentLength = FileTorrent.Length;
            
            System.IO.Stream dataStream = request.GetRequestStream();
            dataStream.Write(FileTorrent, 0, FileTorrent.Length);
            dataStream.Close();

            System.Net.WebResponse response = request.GetResponse();
            dataStream = response.GetResponseStream();
            System.IO.StreamReader reader = new System.IO.StreamReader(dataStream);
            string responseFromServer = reader.ReadToEnd();*/
            Console.WriteLine("GetID="+responseFromServer);
            AceId s = JsonConvert.DeserializeObject<AceId>(responseFromServer);
            if (s.error != null) return "error get content ID: " + s.error;
            else return s.content_id;
        }


        public void GetFileList(string FileTorrentString64, HttpListenerResponse response)
        {
            var result = new List<Item>();

            System.Net.WebClient WC = new System.Net.WebClient();
            WC.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36");
            WC.Encoding = System.Text.UTF8Encoding.UTF8;
            string AceMadiaInfo = null;string ace_url = "";string ace_file_url = "";

            if (FileTorrentString64.IndexOf("magnet") == 0)
            {
                Console.WriteLine("Magnet=" + FileTorrentString64);
                ace_url = "http://" + Settings.Default.IpIPAddress + ":" + PortAce + "/server/api?method=get_media_files&magnet=" + FileTorrentString64;
                ace_file_url = "http://" + Settings.Default.IpIPAddress + ":" + PortAce + "/ace/getstream?magnet="+FileTorrentString64+"&_idx=";
            }
            else
            {
                string ID = GetID(FileTorrentString64, response);
                if (ID.IndexOf("error") == 0)
                {
                    result.Add(
                    new Item
                    {
                        Name = ID,
                        Link = "",
                        Type = ItemType.FILE,
                        ImageLink = "http://obovse.ru/ForkPlayer2.5/img/file.png"
                    }
                    );
                    WriteResponse(response, ResponseSerializer.ToXml(result.ToArray()));
                    return;
                }
                ace_url = "http://" + Settings.Default.IpIPAddress + ":" + PortAce + "/server/api?method=get_media_files&content_id=" + ID;
                ace_file_url = "http://" + Settings.Default.IpIPAddress + ":" + PortAce + "/ace/getstream?id=" + ID + "&_idx=";
            }
            try
            {
                AceMadiaInfo = WC.DownloadString(ace_url);
                WC.Dispose();
            }
            catch(Exception ex)
            {
                result.Add(
                new Item
                {
                    Name = ex.Message + " " + ace_url,
                    Link = "",
                    Description = "<div id=\"poster\" style=\"float:left;padding:4px;	background-color:#EEEEEE;margin:0px 13px 1px 0px;\"><img src=\"http://static.torrentstream.org/sites/org/img/wiki-logo.png\" style=\"width:180px;float:left;\" /></div>" + ace_url + "<br><span style=\"color:#3090F0\">Проверьте, установлен и запущен ли на компьютере Ace Stream!<br>Скачать и установить последнюю версию на компьютер можно по ссылке http://wiki.acestream.org</span>",
                    Type = ItemType.FILE,
                    ImageLink = "http://static.torrentstream.org/sites/org/img/wiki-logo.png"
                }
                );
                WriteResponse(response, ResponseSerializer.ToXml(result.ToArray()));
                return;
            }
            Console.WriteLine(AceMadiaInfo);
            AceFile s =JsonConvert.DeserializeObject< AceFile>(AceMadiaInfo);
            Console.WriteLine(s.error);
            if (s.result == null)
            {
                result.Add(
                new Item
                {
                    Name = AceMadiaInfo,
                    Link = "",
                    Type = ItemType.FILE,
                    ImageLink = "http://obovse.ru/ForkPlayer2.5/img/file.png"
                }
                );
                WriteResponse(response, ResponseSerializer.ToXml(result.ToArray()));
                return;
            }
            List<KeyValuePair<string, string>> myList = new List<KeyValuePair<string, string>>(s.result);
            myList.Sort(
                delegate (KeyValuePair<string, string> firstPair,
                KeyValuePair<string, string> nextPair)
                {
                    return firstPair.Value.CompareTo(nextPair.Value);
                }
            );

            
           
            foreach (var h in myList)
            {
               Console.WriteLine(h.Key + " set=" + h.Value);
               result.Add(
                new Item
                {
                    Name = h.Value,
                    Link = ace_file_url + h.Key,
                    Type = ItemType.FILE,
                    ImageLink= "http://obovse.ru/ForkPlayer2.5/img/file.png"
                }
            );
            }

            foreach (var h in myList)
            {
               Console.WriteLine(h.Key + " set=" + h.Value);
               result.Add(
                new Item
                {
                    Name = "(hls) "+h.Value,
                    Link =  ace_file_url.Replace("getstream", "manifest.m3u8")+ h.Key,
                    Type = ItemType.FILE,
                    ImageLink= "http://obovse.ru/ForkPlayer2.5/img/file.png"
                }
            );
            }
            var playlist = new PluginApi.Plugins.Playlist();
            playlist.Items = result.ToArray();
            playlist.IsIptv = "false";
            WriteResponse(response, ResponseSerializer.ToXml(playlist));
            
        }

    }
}
