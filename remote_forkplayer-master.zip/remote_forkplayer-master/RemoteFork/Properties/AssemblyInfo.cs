﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.38.0.6")]
[assembly:
    Debuggable(
        DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations |
        DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints |
        DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyCompany("ForkPlayer && THVP && AceStream")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.38.0.6")]
[assembly: AssemblyProduct("RemoteFork")]
[assembly: AssemblyTitle("RemoteFork")]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
[assembly: Guid("98a7b532-ab41-401a-9159-ffdf455dfca9")]