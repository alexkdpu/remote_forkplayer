﻿namespace Unosquare.Labs.EmbedIO
{
    public class Log
    {
        public interface ILog
        {
        }
    }
}